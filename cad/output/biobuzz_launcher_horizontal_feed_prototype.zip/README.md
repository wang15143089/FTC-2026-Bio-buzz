# BIOBUZZ 对置飞轮发射机构初模

坐标约定：`X-Y` 为底盘安装平面，`+Z` 向上，`+X` 为发射方向在底盘上的投影。模型单位均为毫米。

## 初版参数

- 发射总成相对底盘倾角：52°
- 96 mm GripForce Gecko，单轴两片、上下共四片
- POLLEN轮缘间隙：64 mm；轴心距160 mm
- NECTAR轮缘间隙：82 mm；轴心距178 mm
- 上下滑台各移动9 mm
- 通道净宽104 mm、净高110 mm
- 水平输送段：163 mm长，球心高56 mm
- 水平转斜向：72 mm主动踢送滚轮＋48 mm弹性上导向滚轮
- 马达包络：Ø38 × 104 mm
- 舵机包络：41 × 21 × 40 mm

`biobuzz_launcher.py`生成POLLEN和NECTAR两个位置的STEP总成、GLB与STL预览网格。STEP保留零件名称与颜色。水平输送原型采用包络建模，包含低位输送带、主动踢送滚轮、弹性上导向滚轮、单球闸门以及约38°到52°的过渡导槽。

## 运行

```powershell
python -m venv .venv-cad
.\.venv-cad\Scripts\python.exe -m pip install -r .\cad\requirements.txt
.\.venv-cad\Scripts\python.exe .\cad\biobuzz_launcher.py
```

输出位于`cad/output/`。

## 倾角计算假设

初算采用：发射口高度0.34 m、目标中心高度1.15 m、水平距离1.50 m。真空弹道的最低能耗角约59.2°；模型采用52°，以缩短带孔球的滞空时间、降低气动离散、控制机构高度，并预留42°～58°的长孔机械调角范围。该角度必须在真实场地以不同距离和球体样本继续标定。

## 需要实物确认的尺寸

- Gecko轮实际厚度、轮毂紧固方式及高速径向膨胀
- 选用马达和联轴器的法兰孔位
- 选用舵机的耳板孔距和输出轴高度
- 底盘梁位置及机器人起始包络
- CELL实际目标中心、机器人允许发射位置与常用射距
