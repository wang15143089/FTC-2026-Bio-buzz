"""Render a cutaway preview of the constrained NECTAR configuration."""

from pathlib import Path
import vtk

OUT = Path(__file__).resolve().parent / "output"

reader = vtk.vtkSTLReader()
reader.SetFileName(str(OUT / "paddle_launcher_constrained_nectar.stl"))

# Remove the near half so both opposed shafts and the paddle rotor remain visible.
plane = vtk.vtkPlane()
plane.SetOrigin(0, -8, 0)
plane.SetNormal(0, 1, 0)
clip = vtk.vtkClipPolyData()
clip.SetInputConnection(reader.GetOutputPort())
clip.SetClipFunction(plane)
clip.InsideOutOff()

normals = vtk.vtkPolyDataNormals()
normals.SetInputConnection(clip.GetOutputPort())
normals.SetFeatureAngle(42)

mapper = vtk.vtkPolyDataMapper()
mapper.SetInputConnection(normals.GetOutputPort())
actor = vtk.vtkActor()
actor.SetMapper(mapper)
actor.GetProperty().SetColor(0.71, 0.79, 0.89)
actor.GetProperty().SetMetallic(0.18)
actor.GetProperty().SetRoughness(0.52)

ground = vtk.vtkPlaneSource()
ground.SetOrigin(-180, -150, 0)
ground.SetPoint1(245, -150, 0)
ground.SetPoint2(-180, 150, 0)
gm = vtk.vtkPolyDataMapper()
gm.SetInputConnection(ground.GetOutputPort())
ga = vtk.vtkActor()
ga.SetMapper(gm)
ga.GetProperty().SetColor(0.16, 0.50, 0.29)
ga.GetProperty().SetOpacity(0.16)

axes = vtk.vtkAxesActor()
axes.SetTotalLength(75, 75, 75)
axes.SetShaftTypeToCylinder()
axes.SetCylinderRadius(0.013)

label = vtk.vtkTextActor()
label.SetInput("CONSTRAINED NECTAR CONFIG  |  52 deg  |  X-Y CHASSIS PLANE")
label.SetPosition(35, 945)
label.GetTextProperty().SetFontSize(25)
label.GetTextProperty().SetColor(0.90, 0.94, 1.00)

ren = vtk.vtkRenderer()
ren.SetBackground(0.030, 0.042, 0.063)
ren.AddActor(actor)
ren.AddActor(ga)
ren.AddActor(axes)
ren.AddActor2D(label)

win = vtk.vtkRenderWindow()
win.SetOffScreenRendering(1)
win.SetSize(1600, 1000)
win.AddRenderer(ren)
cam = ren.GetActiveCamera()
cam.SetPosition(570, -720, 470)
cam.SetFocalPoint(15, 0, 190)
cam.SetViewUp(0, 0, 1)
ren.ResetCameraClippingRange()
win.Render()

capture = vtk.vtkWindowToImageFilter()
capture.SetInput(win)
capture.SetInputBufferTypeToRGBA()
capture.ReadFrontBufferOff()
capture.Update()
writer = vtk.vtkPNGWriter()
writer.SetFileName(str(OUT / "paddle_launcher_constrained_preview.png"))
writer.SetInputConnection(capture.GetOutputPort())
writer.Write()
